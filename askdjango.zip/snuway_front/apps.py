from django.apps import AppConfig


class SnuwayFrontConfig(AppConfig):
    name = 'snuway_front'
